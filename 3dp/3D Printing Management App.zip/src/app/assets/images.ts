/**
 * 图片资源统一管理
 * 所有商品图片、图标等资源都在这里定义
 * 方便后续统一替换为真实图片URL
 */

// 商品图片
export const ProductImages = {
  // 耗材类
  PLA_WHITE: '🧵',
  PLA_BLACK: '🧵',
  
  // 成品类
  DESK_LAMP: '💡',
  KEY_CHAIN: '🔑',
  
  // 模型类
  PHONE_STAND: '📱',
  PEN_HOLDER: '✏️',
};

// 占位符图片（可以替换为真实的占位图URL）
export const PlaceholderImages = {
  DEFAULT: '📦',
  LOADING: '⏳',
  ERROR: '❌',
};

// Banner背景图片
export const BannerImages = [
  'https://media.istockphoto.com/id/1365090516/photo/coils-with-bright-multi-colored-wire-close-up-blurry.jpg?s=1024x1024&w=is&k=20&c=gFk3H04DGnDl3v70rDZK8r3YmxV4IRLezTZK5nTU52k=',
  'https://images.unsplash.com/photo-1615286922420-c6b348ffbd62?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  'https://images.unsplash.com/photo-1642969164999-979483e21601?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
];

// 导出所有图片资源
export const Images = {
  products: ProductImages,
  placeholder: PlaceholderImages,
  banners: BannerImages,
};

export default Images;