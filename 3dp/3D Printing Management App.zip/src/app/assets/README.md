# 图片资源管理目录

这个目录用于统一管理应用中所有的图片资源。

## 文件说明

### `images.ts`
集中管理所有商品图片、图标等资源的配置文件。

## 使用方法

### 1. 导入图片资源
```typescript
import Images from './assets/images';
```

### 2. 在代码中使用
```typescript
// 使用商品图片
const product = {
  name: 'PLA 耗材',
  image: Images.products.PLA_WHITE
};

// 使用占位符
const placeholder = Images.placeholder.DEFAULT;
```

## 替换图片

### 方式一：使用表情符号（当前方式）
直接在 `images.ts` 中修改对应的表情符号即可。

### 方式二：替换为真实图片URL
当您有真实图片时，可以这样替换：

```typescript
export const ProductImages = {
  // 替换为真实图片URL
  PLA_WHITE: 'https://example.com/images/pla-white.jpg',
  PLA_BLACK: 'https://example.com/images/pla-black.jpg',
  DESK_LAMP: 'https://example.com/images/desk-lamp.jpg',
  // ...
};
```

### 方式三：使用本地图片
如果图片存储在项目中：

```typescript
import plaWhite from './images/pla-white.jpg';
import plaBlack from './images/pla-black.jpg';

export const ProductImages = {
  PLA_WHITE: plaWhite,
  PLA_BLACK: plaBlack,
  // ...
};
```

## 添加新图片

在 `images.ts` 中添加新的图片资源：

```typescript
export const ProductImages = {
  // 现有图片...
  
  // 新增图片
  NEW_PRODUCT: '🆕',  // 或者图片URL
};
```

## 最佳实践

1. **统一管理**：所有图片都通过这个文件引用，避免在代码中硬编码
2. **易于维护**：需要更换图片时，只需修改这一个文件
3. **类型安全**：使用TypeScript确保图片引用的正确性
4. **分类清晰**：按照图片用途进行分类（商品、占位符等）
