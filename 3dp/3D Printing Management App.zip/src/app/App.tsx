import React, { useState, useEffect, useMemo } from "react";
import {
  MapPin,
  Bell,
  ChevronRight,
  ChevronLeft,
  Upload,
  X,
  ShoppingCart,
  User,
  Printer,
  FileText,
  Settings,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Thermometer,
  Clock,
  Package,
  Plus,
  Minus,
  FileBox,
  Info,
  List,
  Loader2,
  AlertTriangle,
  QrCode,
  LogOut,
  Trash2,
  StopCircle,
  ShoppingBag,
  PenTool,
  Download,
  Palette,
  Phone,
  Layers,
  Image as ImageIcon,
  Ruler,
  MessageSquare,
  Navigation,
  ChevronDown,
  Users,
  Monitor,
  LocateFixed,
  Zap,
  Star,
} from "lucide-react";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import logoImage from "figma:asset/d36132d6e0e2b567f2261b427293818dfcaba800.png";
import Images from "./assets/images";

// --- Types & Constants ---

type Role = "GUEST" | "CAMPUS" | "COURSE";

interface UserProfile {
  name: string;
  role: Role;
  quota: number;
  avatar: string;
  addresses: Address[];
}

interface Address {
  id: string;
  name: string;
  phone: string;
  detail: string;
  tag: string;
  isDefault: boolean;
}

type TaskStatus =
  | "QUEUED"
  | "PRINTING"
  | "COMPLETED"
  | "EXCEPTION";

interface Task {
  id: string;
  printerId: string;
  name: string;
  thumb: string;
  status: TaskStatus;
  progress: number;
  info: string;
  temps?: { nozzle: number; bed: number };
  timeLeft?: number; // minutes
}

interface AddOn {
  id: string;
  name: string;
  price: number;
}

interface Product {
  id: string;
  name: string;
  price: number;
  type: "PHYSICAL" | "VIRTUAL" | "PRINT_SERVICE";
  image: string;
  category: string;
  desc: string;
  addOns?: AddOn[];
  material?: string; // 材质
  dimensions?: string; // 尺寸
  weight?: string; // 耗材重量
}

interface CartItem extends Product {
  quantity: number;
  selectedAddOn?: AddOn | null;
}

interface Order {
  id: string;
  status: "PENDING" | "SHIPPED" | "COMPLETED";
  total: number;
  items: CartItem[]; // Store full items to know if they are printable
  date: string;
}

interface Notification {
  id: string;
  title: string;
  content: string;
  time: string;
  read: boolean;
  type: "SYSTEM" | "ORDER" | "CUSTOM";
}

const MOCK_BANNERS = [
  "高校3D打印活动",
  "新手必看：如何避免悬空？",
  "第三届3D打印设计大赛",
];

const SICHUAN_UNIVERSITIES = [
  "西南财经大学",
  "四川农业大学",
  "成都中医药大学",
  "成都师范学院",
  "四川交通职业技术学院",
  "成都农业科技职业学院",
];

const MOCK_PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "PLA 耗材 (1kg) 白色",
    price: 69,
    type: "PHYSICAL",
    image: Images.products.PLA_WHITE,
    category: "耗材",
    desc: "高品质PLA线材，直径1.75mm，无气泡，不堵头。",
    material: "PLA",
    weight: "1000g",
  },
  {
    id: "p2",
    name: "PLA 耗材 (1kg) 黑色",
    price: 69,
    type: "PHYSICAL",
    image: Images.products.PLA_BLACK,
    category: "耗材",
    desc: "经典黑色PLA，哑光质感。",
    material: "PLA",
    weight: "1000g",
  },
  {
    id: "p3",
    name: "桌面台灯 (成品)",
    price: 129,
    type: "PHYSICAL",
    image: Images.products.DESK_LAMP,
    category: "成品",
    desc: "由3D打印制作的创意台灯，含LED灯芯，USB供电。",
    material: "PLA+",
    dimensions: "120×120×180mm",
    weight: "85g",
  },
  {
    id: "p4",
    name: "校徽钥匙扣",
    price: 15,
    type: "PHYSICAL",
    image: Images.products.KEY_CHAIN,
    category: "成品",
    desc: "高校联名款钥匙扣，PLA材质。",
    material: "PLA",
    dimensions: "40×40×3mm",
    weight: "8g",
  },
  {
    id: "p5",
    name: "手机支架模型",
    price: 9.9,
    type: "VIRTUAL",
    image: Images.products.PHONE_STAND,
    category: "模型",
    desc: "通用的手机支架STL文件，购买后可直接生成打印任务或下载。",
    material: "PLA",
    dimensions: "80×65×70mm",
    weight: "35g",
    addOns: [
      { id: "a1", name: "刻字", price: 5 },
      { id: "a2", name: "潮玩", price: 2 },
    ],
  },
  {
    id: "p6",
    name: "笔筒模型",
    price: 19.9,
    type: "PRINT_SERVICE",
    image: Images.products.PEN_HOLDER,
    category: "模型",
    desc: "创意笔筒模型，支持附加个性化装饰。",
    material: "PLA",
    dimensions: "90×90×110mm",
    weight: "52g",
    addOns: [
      { id: "a3", name: "浮雕文字", price: 5 },
      { id: "a4", name: "潮玩", price: 15 },
      { id: "a5", name: "笔筒盖", price: 8 },
    ],
  },
];

// --- Config Maps ---

const TASK_STATUS_MAP: Record<TaskStatus, string> = {
  QUEUED: "排队中",
  PRINTING: "打印中",
  COMPLETED: "待取件",
  EXCEPTION: "异常",
};

const ORDER_STATUS_MAP: Record<string, string> = {
  PENDING: "处理中",
  SHIPPED: "已发货",
  COMPLETED: "已完成",
};

// --- Shared Components ---

// Success Modal Component
const SuccessModal = ({
  isOpen,
  onClose,
  title,
  message,
  icon = "✨",
}: {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  icon?: string;
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-sm p-8 animate-in zoom-in duration-300 shadow-2xl">
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center text-3xl mb-4 animate-bounce">
            {icon}
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">
            {title}
          </h3>
          <p className="text-gray-600 text-sm leading-relaxed mb-6">
            {message}
          </p>
          <button
            onClick={onClose}
            className="w-full py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-full font-bold shadow-lg shadow-blue-200 active:scale-95 transition-transform"
          >
            我知道了
          </button>
        </div>
      </div>
    </div>
  );
};

// Delete Confirmation Modal Component
const DeleteConfirmModal = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
}: {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-[70] flex items-center justify-center p-6 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl w-full max-w-sm p-8 animate-in zoom-in duration-300 shadow-2xl">
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-pink-600 rounded-full flex items-center justify-center text-3xl mb-4">
            ⚠️
          </div>
          <h3 className="text-xl font-bold text-gray-800 mb-2">
            {title}
          </h3>
          <p className="text-gray-600 text-sm leading-relaxed mb-6">
            {message}
          </p>
          <div className="flex gap-3 w-full">
            <button
              onClick={onClose}
              className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-full font-bold active:scale-95 transition-transform"
            >
              取消
            </button>
            <button
              onClick={onConfirm}
              className="flex-1 py-3 bg-gradient-to-r from-red-500 to-pink-600 text-white rounded-full font-bold shadow-lg shadow-red-200 active:scale-95 transition-transform"
            >
              确认删除
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const BannerCarousel = () => {
  const [index, setIndex] = useState(0);
  useEffect(() => {
    const timer = setInterval(
      () =>
        setIndex((prev) => (prev + 1) % MOCK_BANNERS.length),
      3000,
    );
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative h-40 rounded-2xl overflow-hidden shadow-lg shadow-blue-200 mt-4 mx-4 transform transition-all duration-500">
      {MOCK_BANNERS.map((b, i) => (
        <div
          key={i}
          className={`absolute inset-0 transition-opacity duration-700 ${i === index ? "opacity-100" : "opacity-0"}`}
        >
          {/* 背景图片 */}
          <div
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url(${Images.banners[i]})`,
            }}
          />
          {/* 深色遮罩层，确保文字清晰可读 */}
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/70 to-indigo-900/70" />
          {/* 文字内容 */}
          <div className="relative h-full flex items-center justify-center text-white font-bold p-4 text-center">
            {b}
          </div>
        </div>
      ))}
      <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1.5 z-10">
        {MOCK_BANNERS.map((_, i) => (
          <div
            key={i}
            className={`h-1.5 rounded-full transition-all ${i === index ? "w-4 bg-white" : "w-1.5 bg-white/40"}`}
          />
        ))}
      </div>
    </div>
  );
};

const CustomNavBar = ({
  university,
  status,
  onMsg,
  onMap,
  unreadCount,
}: {
  university: string;
  status: string;
  onMsg: () => void;
  onMap: () => void;
  unreadCount: number;
}) => (
  <div className="bg-white pt-12 pb-3 px-4 flex justify-between items-start shadow-sm sticky top-0 z-50">
    <div className="flex items-start gap-3">
      <ImageWithFallback
        src={logoImage}
        alt="Logo"
        className="w-12 h-12 object-contain flex-shrink-0 mt-1 rounded-lg"
      />
      <div className="flex flex-col">
        <span className="font-bold text-xl text-gray-800">
          高校3D打印
        </span>
        <div className="flex items-center gap-2 mt-1.5 text-xs">
          <span className="font-medium text-gray-700">
            {university}
          </span>
          <span
            className={`w-2 h-2 rounded-full ${status === "营业中" ? "bg-green-500" : "bg-orange-500"}`}
          ></span>
          <span className="text-gray-500">{status}</span>
        </div>
      </div>
    </div>
    <div className="flex gap-3 flex-shrink-0">
      <div
        onClick={onMap}
        className="p-2 bg-gray-100 rounded-full cursor-pointer hover:bg-gray-200"
      >
        <MapPin size={20} className="text-gray-700" />
      </div>
      <div
        onClick={onMsg}
        className="p-2 bg-gray-100 rounded-full cursor-pointer hover:bg-gray-200 relative"
      >
        <Bell size={20} className="text-gray-700" />
        {unreadCount > 0 && (
          <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-bounce"></div>
        )}
      </div>
    </div>
  </div>
);

const AuthModal = ({
  isOpen,
  onClose,
  onAuth,
}: {
  isOpen: boolean;
  onClose: () => void;
  onAuth: (role: Role, name: string) => void;
}) => {
  const [studentId, setStudentId] = useState("");
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!studentId || !code) return alert("请填写完整信息");
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (studentId === "0" && code === "0") {
        onAuth("COURSE", "李同学 (课程)");
        onClose();
      } else if (studentId === "1" && code === "1") {
        onAuth("CAMPUS", "王同学 (校园)");
        onClose();
      } else {
        alert(
          "认证失败：无效的学号或课程代码 (提示: 课程学生输入0/0, 校园学生输入1/1)",
        );
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl w-full max-w-sm p-6 animate-in fade-in zoom-in duration-200">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-xl font-bold">身份绑定</h3>
          <button onClick={onClose}>
            <X size={20} className="text-gray-400" />
          </button>
        </div>
        <p className="text-sm text-gray-500 mb-6">
          请输入学号与课程代码激活权益
        </p>
        <div className="space-y-4">
          <input
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
            type="number"
            placeholder="学号 (测试: 0 或 1)"
            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 focus:outline-blue-500"
          />
          <input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="课程代码 (测试: 0 或 1)"
            className="w-full p-3 bg-gray-50 rounded-lg border border-gray-200 focus:outline-blue-500"
          />
        </div>
        <div className="mt-8">
          <button
            onClick={handleSubmit}
            className="w-full py-3 bg-blue-600 text-white rounded-full font-medium shadow-lg shadow-blue-200 active:scale-95 transition-transform"
          >
            {loading ? "校验中..." : "立即绑定"}
          </button>
          <p className="text-xs text-center text-gray-400 mt-4">
            测试说明：课程学生输 0/0，校园学生输 1/1
          </p>
        </div>
      </div>
    </div>
  );
};

const MapPage = ({
  back,
  info,
  setInfo,
}: {
  back: () => void;
  info: { name: string; status: string };
  setInfo: any;
}) => {
  const [showSelector, setShowSelector] = useState(false);
  const [locating, setLocating] = useState(false);

  // Mock Real-time Data
  const realtime = useMemo(() => {
    const isBusy = info.status === "忙碌";
    return {
      avail: isBusy ? 0 : 3,
      queue: isBusy ? 25 : 0,
      color: isBusy ? "text-orange-500" : "text-green-600",
      bgColor: isBusy ? "bg-orange-500" : "bg-green-500",
      pinColor: isBusy ? "text-orange-500" : "text-green-500",
    };
  }, [info.status]);

  const handleSwitchCampus = (name: string) => {
    setInfo({
      name,
      status: Math.random() > 0.5 ? "营业中" : "忙碌",
    });
    setShowSelector(false);
  };

  const handleRelocate = () => {
    setLocating(true);
    setTimeout(() => {
      setLocating(false);
    }, 1000);
  };

  return (
    <div className="h-full bg-gray-50 flex flex-col">
      <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
        <button onClick={back}>
          <ChevronLeft />
        </button>
        <h2 className="font-bold text-lg">场馆位置</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col">
        {/* Venue Selector */}
        <div className="mb-4 relative z-20 shrink-0">
          <div
            className="flex justify-between items-center cursor-pointer bg-white p-4 rounded-2xl border border-gray-100 shadow-sm active:bg-gray-50"
            onClick={() => setShowSelector(!showSelector)}
          >
            <div className="flex flex-col">
              <span className="text-xs text-gray-400 mb-1">
                当前场馆
              </span>
              <span className="font-bold text-gray-800 text-lg line-clamp-1">
                {info.name}
              </span>
            </div>
            <ChevronDown
              size={20}
              className={`text-gray-400 transition-transform ${showSelector ? "rotate-180" : ""}`}
            />
          </div>

          {showSelector && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 max-h-48 overflow-y-auto p-2">
              {SICHUAN_UNIVERSITIES.map((uni) => (
                <div
                  key={uni}
                  onClick={() => handleSwitchCampus(uni)}
                  className={`p-3 rounded-lg text-sm mb-1 cursor-pointer ${info.name === uni ? "bg-blue-50 text-blue-600 font-bold" : "hover:bg-gray-50 text-gray-600"}`}
                >
                  {uni}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Map Visual with Status Marking */}
        <div className="w-full aspect-[4/3] bg-blue-50 rounded-2xl mb-5 border-2 border-white shadow-sm overflow-hidden relative group z-10 shrink-0">
          {/* Map Pattern */}
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage:
                "radial-gradient(#2B6DE5 1px, transparent 1px)",
              backgroundSize: "10px 10px",
            }}
          ></div>

          {/* Routes Animation */}
          <svg
            className="absolute inset-0 w-full h-full pointer-events-none"
            style={{ opacity: 0.6 }}
          >
            <path
              d="M50,220 Q150,50 300,100"
              stroke="#2B6DE5"
              strokeWidth="3"
              fill="none"
              strokeDasharray="6 4"
              className="animate-[dash_10s_linear_infinite]"
            />
          </svg>

          {/* Current Location Pin & Relocate */}
          <div className="absolute bottom-6 left-6 flex items-end gap-2">
            <div className="flex flex-col items-center">
              <div
                className={`w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-md ${locating ? "animate-ping" : "animate-pulse"}`}
              ></div>
              <span className="text-[10px] bg-white px-1.5 rounded shadow mt-1 font-medium text-gray-600">
                我的位置
              </span>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleRelocate();
              }}
              className="bg-white p-1.5 rounded-full shadow-sm border border-gray-100 text-gray-600 active:scale-95 transition-transform"
            >
              {locating ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <LocateFixed size={16} />
              )}
            </button>
          </div>

          {/* Venue Pin with Live Status Bubble */}
          <div className="absolute top-1/4 right-1/4 flex flex-col items-center group cursor-pointer transition-transform hover:scale-105">
            {/* Live Status Bubble */}
            <div
              className={`mb-1 px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow-md transform ${realtime.bgColor} flex flex-col items-center`}
            >
              <span>
                {realtime.queue > 0
                  ? `排队 ${realtime.queue}m`
                  : `空闲 (${realtime.avail}台)`}
              </span>
            </div>

            <MapPin
              size={40}
              className={`${realtime.pinColor} drop-shadow-lg -mb-1`}
              fill="currentColor"
            />
            <div className="w-3 h-1.5 bg-black/20 rounded-full blur-[2px]"></div>
          </div>
        </div>

        <div className="space-y-4 flex-1">
          {/* Status & Hours Card */}
          <div className="bg-white border border-gray-100 shadow-sm rounded-xl p-4">
            <div className="flex justify-between items-center border-b border-gray-50 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <div
                  className={`w-2.5 h-2.5 rounded-full ${realtime.bgColor} animate-pulse`}
                ></div>
                <span className="font-bold text-lg text-gray-800">
                  {info.status}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-gray-500 text-sm">
                <Clock size={14} />
                <span className="font-mono">08:30 - 22:00</span>
              </div>
            </div>

            <div className="flex divide-x divide-gray-100">
              <div className="flex-1 flex flex-col items-center">
                <span className="text-xs text-gray-400 mb-1 flex items-center gap-1">
                  <Printer size={12} /> 可用打印机
                </span>
                <span className="font-bold text-xl text-gray-800 flex items-center gap-1">
                  {realtime.avail}{" "}
                  <span className="text-xs font-normal text-gray-400">
                    / 10台
                  </span>
                </span>
              </div>
              <div className="flex-1 flex flex-col items-center">
                <span className="text-xs text-gray-400 mb-1 flex items-center gap-1">
                  <Users size={12} /> 预计排队
                </span>
                <span
                  className={`font-bold text-xl flex items-center gap-1 ${realtime.queue > 20 ? "text-orange-500" : "text-green-600"}`}
                >
                  {realtime.queue}{" "}
                  <span className="text-xs font-normal text-gray-400">
                    分钟
                  </span>
                </span>
              </div>
            </div>
          </div>

          {/* Address Detail */}
          <div className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex items-start gap-4">
            <div className="bg-gray-100 p-2.5 rounded-full">
              <MapPin size={20} className="text-gray-600" />
            </div>
            <div>
              <div className="text-xs text-gray-400 mb-1">
                详细地址
              </div>
              <div className="text-sm font-medium text-gray-800 leading-tight">
                基础教学楼 B座 305室 创新实验室
              </div>
              <div className="text-xs text-blue-500 mt-1">
                距离您当前位置约 1.2km
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={() => alert("正在打开第三方地图导航...")}
          className="w-full py-4 bg-blue-600 text-white font-bold rounded-full shadow-lg shadow-blue-200 flex items-center justify-center gap-2 active:scale-95 transition-transform mt-2 shrink-0"
        >
          <Navigation size={20} /> 开始导航
        </button>
      </div>
    </div>
  );
};

// --- Page Components ---

// 1. ShopList
const ShopList = ({
  cart,
  setCart,
  navigate,
}: {
  cart: CartItem[];
  setCart: React.Dispatch<React.SetStateAction<CartItem[]>>;
  navigate: (view: string) => void;
}) => {
  const [category, setCategory] = useState("全部");
  const [selectedProduct, setSelectedProduct] =
    useState<Product | null>(null);
  const [showCart, setShowCart] = useState(false);
  const [selectedAddOn, setSelectedAddOn] =
    useState<AddOn | null>(null);
  const [touchStart, setTouchStart] = useState<number | null>(
    null,
  );
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const categories = ["全部", "耗材", "成品", "模型"];
  const filteredProducts =
    category === "全部"
      ? MOCK_PRODUCTS
      : MOCK_PRODUCTS.filter((p) => p.category === category);

  // 最小滑动距离
  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    const currentIndex = categories.indexOf(category);

    if (isLeftSwipe && currentIndex < categories.length - 1) {
      // 向左滑动，切换到下一个品类
      setCategory(categories[currentIndex + 1]);
    }

    if (isRightSwipe && currentIndex > 0) {
      // 向右滑动，切换到上一个品类
      setCategory(categories[currentIndex - 1]);
    }
  };

  useEffect(() => {
    setSelectedAddOn(null);
  }, [selectedProduct]);

  const addToCart = (
    product: Product,
    quantity = 1,
    addOn: AddOn | null = null,
  ) => {
    setCart((prev) => {
      const uniqueId = addOn
        ? `${product.id}_${addOn.id}`
        : product.id;
      const existing = prev.find((item) => {
        const itemId = item.selectedAddOn
          ? `${item.id}_${item.selectedAddOn.id}`
          : item.id;
        return itemId === uniqueId;
      });

      if (existing) {
        return prev.map((item) => {
          const itemId = item.selectedAddOn
            ? `${item.id}_${item.selectedAddOn.id}`
            : item.id;
          return itemId === uniqueId
            ? { ...item, quantity: item.quantity + quantity }
            : item;
        });
      }
      return [
        ...prev,
        { ...product, quantity, selectedAddOn: addOn },
      ];
    });
  };

  const updateQuantity = (
    cartItemIndex: number,
    delta: number,
  ) => {
    setCart((prev) =>
      prev
        .map((item, idx) => {
          if (idx === cartItemIndex)
            return {
              ...item,
              quantity: Math.max(0, item.quantity + delta),
            };
          return item;
        })
        .filter((item) => item.quantity > 0),
    );
  };

  const removeItem = (cartItemIndex: number) => {
    setCart((prev) =>
      prev.filter((_, idx) => idx !== cartItemIndex),
    );
  };

  const calculateItemPrice = (item: CartItem) => {
    return (
      (item.price + (item.selectedAddOn?.price || 0)) *
      item.quantity
    );
  };

  const cartTotal = cart.reduce(
    (sum, item) => sum + calculateItemPrice(item),
    0,
  );
  const cartCount = cart.reduce(
    (sum, item) => sum + item.quantity,
    0,
  );

  return (
    <div className="pb-24 bg-gray-50 min-h-screen flex flex-col">
      {/* Header */}
      <div className="bg-white pt-12 pb-2 px-4 sticky top-0 z-10 shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-bold">商城</h1>
          <div className="flex gap-4">
            <div onClick={() => navigate("ORDER_LIST")}>
              <List className="text-gray-700" />
            </div>
            <div
              onClick={() => setShowCart(true)}
              className="relative cursor-pointer"
            >
              <ShoppingCart className="text-gray-700" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">
                  {cartCount}
                </span>
              )}
            </div>
          </div>
        </div>
        {/* Categories Tab */}
        <div className="flex gap-4 overflow-x-auto pb-2 hide-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${category === cat ? "bg-blue-600 text-white shadow-md shadow-blue-200" : "bg-gray-100 text-gray-500"}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <div
        className="p-4 grid grid-cols-2 gap-4 flex-1 overflow-y-auto"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {filteredProducts.map((p) => (
          <div
            key={p.id}
            onClick={() => setSelectedProduct(p)}
            className="bg-white p-3 rounded-xl shadow-sm active:scale-95 transition-transform flex flex-col h-[260px]"
          >
            <div className="h-32 bg-gray-100 rounded-lg flex items-center justify-center text-4xl mb-3 flex-shrink-0">
              {p.image}
            </div>
            <h3 className="font-bold text-gray-900 text-sm mb-2 line-clamp-2">
              {p.name}
            </h3>
            <div className="flex items-center gap-1 flex-wrap mb-auto">
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded ${p.type === "PHYSICAL" ? "bg-orange-50 text-orange-600" : "bg-blue-50 text-blue-600"}`}
              >
                {p.type === "PHYSICAL" ? "实体" : "虚拟"}
              </span>
              {p.addOns && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-50 text-purple-600">
                  可定制
                </span>
              )}
            </div>
            <div className="mt-2 flex justify-between items-center pt-2 border-t border-gray-50">
              <span className="text-red-500 font-bold text-base">
                ¥{p.price}
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  addToCart(p);
                }}
                className="w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-200"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Product Detail Modal (Bottom Sheet) */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setSelectedProduct(null)}
          ></div>

          {/* Modal Content */}
          <div className="bg-white w-full max-w-md rounded-t-3xl p-6 relative animate-in slide-in-from-bottom duration-300 z-10 max-h-[80vh] overflow-y-auto">
            <button
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full text-gray-500"
            >
              <X size={20} />
            </button>

            <div className="flex gap-6 mb-6">
              <div className="w-28 h-28 bg-gray-100 rounded-2xl flex items-center justify-center text-6xl">
                {selectedProduct.image}
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {selectedProduct.name}
                </h3>
                <div className="flex flex-wrap gap-2 mb-3">
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-500">
                    {selectedProduct.category}
                  </span>
                  <span
                    className={`text-xs px-2 py-1 rounded ${selectedProduct.type === "PHYSICAL" ? "bg-orange-50 text-orange-600" : "bg-blue-50 text-blue-600"}`}
                  >
                    {selectedProduct.type === "PHYSICAL"
                      ? "需物流"
                      : "自动生成任务"}
                  </span>
                </div>
                <div className="flex items-baseline gap-2">
                  <div className="text-2xl font-bold text-red-500">
                    ¥
                    {(
                      selectedProduct.price +
                      (selectedAddOn?.price || 0)
                    ).toFixed(2)}
                  </div>
                  {selectedAddOn && (
                    <div className="text-sm text-gray-400 line-through">
                      ¥{selectedProduct.price}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Specs Card */}
            {(selectedProduct.material ||
              selectedProduct.dimensions ||
              selectedProduct.weight) && (
              <div className="mb-6 bg-gray-50 p-4 rounded-xl grid grid-cols-3 divide-x divide-gray-200">
                {selectedProduct.material && (
                  <div className="text-center px-2">
                    <div className="text-xs text-gray-500 mb-1">
                      材质
                    </div>
                    <div className="text-sm font-bold text-gray-900">
                      {selectedProduct.material}
                    </div>
                  </div>
                )}
                {selectedProduct.dimensions && (
                  <div className="text-center px-2">
                    <div className="text-xs text-gray-500 mb-1">
                      尺寸
                    </div>
                    <div className="text-xs font-bold text-gray-900">
                      {selectedProduct.dimensions}
                    </div>
                  </div>
                )}
                {selectedProduct.weight && (
                  <div className="text-center px-2">
                    <div className="text-xs text-gray-500 mb-1">
                      耗材重量
                    </div>
                    <div className="text-sm font-bold text-gray-900">
                      {selectedProduct.weight}
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="mb-6">
              <h4 className="font-bold mb-2 text-sm text-gray-900">
                商品描述
              </h4>
              <p className="text-sm text-gray-500 leading-relaxed bg-gray-50 p-4 rounded-xl">
                {selectedProduct.desc}
              </p>
            </div>

            {/* Add-ons Selection */}
            {selectedProduct.addOns && (
              <div className="mb-8">
                <h4 className="font-bold mb-3 text-sm text-gray-900 flex items-center gap-2">
                  <Palette size={16} /> 附加模型 / 定制 (可选)
                </h4>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedAddOn(null)}
                    className={`px-4 py-2 rounded-lg text-sm border ${selectedAddOn === null ? "bg-blue-50 border-blue-600 text-blue-600 font-bold" : "border-gray-200 text-gray-600"}`}
                  >
                    无定制
                  </button>
                  {selectedProduct.addOns.map((addon) => (
                    <button
                      key={addon.id}
                      onClick={() => setSelectedAddOn(addon)}
                      className={`px-4 py-2 rounded-lg text-sm border ${selectedAddOn?.id === addon.id ? "bg-purple-50 border-purple-600 text-purple-600 font-bold" : "border-gray-200 text-gray-600"}`}
                    >
                      {addon.name} (+¥{addon.price})
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3">
              <button
                onClick={() => {
                  addToCart(selectedProduct, 1, selectedAddOn);
                  setSelectedProduct(null);
                }}
                className="flex-1 py-3.5 bg-blue-50 text-blue-600 font-bold rounded-full"
              >
                加入购物车
              </button>
              {/* Special Case: If it's a model that supports extensive customization, we can link to custom form, else direct buy */}
              <button
                onClick={() => {
                  addToCart(selectedProduct, 1, selectedAddOn);
                  setSelectedProduct(null);
                  navigate("CHECKOUT");
                }}
                className="flex-1 py-3.5 bg-blue-600 text-white font-bold rounded-full shadow-lg shadow-blue-200"
              >
                立即购买
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cart Popup (Bottom Sheet) */}
      {showCart && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          {/* Backdrop with explicit close */}
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setShowCart(false)}
          ></div>

          <div
            className="bg-white w-full max-w-md rounded-t-3xl flex flex-col relative z-10 animate-in slide-in-from-bottom duration-300"
            style={{ maxHeight: "80vh" }}
          >
            <div className="p-4 border-b flex justify-between items-center">
              <div className="flex items-center gap-2">
                <ShoppingBag size={20} />
                <span className="font-bold">
                  购物车 ({cartCount})
                </span>
              </div>
              <button
                onClick={() => {
                  setCart([]);
                }}
                className="text-xs text-gray-400 flex items-center gap-1 hover:text-red-500"
              >
                <Trash2 size={12} /> 清空
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center text-gray-400 py-10">
                  购物车空空如也
                </div>
              ) : (
                cart.map((item, index) => (
                  <div
                    key={index}
                    className="flex gap-4 items-center bg-white border-b border-gray-50 pb-4 last:border-0"
                  >
                    <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center text-2xl">
                      {item.image}
                    </div>
                    <div className="flex-1 flex flex-col justify-between h-16">
                      <div className="font-bold text-sm line-clamp-1">
                        {item.name}
                      </div>
                      {item.selectedAddOn && (
                        <div className="text-xs text-purple-600 bg-purple-50 self-start px-1.5 rounded">
                          + {item.selectedAddOn.name} (¥
                          {item.selectedAddOn.price})
                        </div>
                      )}
                      <div className="flex justify-between items-end mt-auto">
                        <span className="text-red-500 font-bold">
                          ¥
                          {(
                            item.price +
                            (item.selectedAddOn?.price || 0)
                          ).toFixed(2)}
                        </span>
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() =>
                              updateQuantity(index, -1)
                            }
                            className="w-6 h-6 rounded-full border flex items-center justify-center text-gray-500 active:bg-gray-100"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="text-sm font-medium w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              updateQuantity(index, 1)
                            }
                            className="w-6 h-6 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center active:bg-blue-100"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                    {/* Independent Delete Button */}
                    <button
                      onClick={() => removeItem(index)}
                      className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="p-4 border-t bg-white pb-8 safe-area-bottom">
              <div className="flex justify-between items-center mb-4">
                <span className="text-gray-500">计</span>
                <span className="text-xl font-bold text-red-600">
                  ¥{cartTotal.toFixed(2)}
                </span>
              </div>
              <button
                disabled={cart.length === 0}
                onClick={() => {
                  setShowCart(false);
                  navigate("CHECKOUT");
                }}
                className="w-full py-3.5 bg-blue-600 text-white font-bold rounded-full shadow-lg disabled:bg-gray-300 disabled:shadow-none"
              >
                去结算
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// 2. UploadPage
const UploadPage = ({
  mode,
  user,
  setUser,
  setTasks,
  switchTab,
  back,
}: any) => {
  const [step, setStep] = useState<"FILE" | "PARAMS">("FILE");
  const [analyzing, setAnalyzing] = useState(false);
  const [volume, setVolume] = useState(800);
  const [material, setMaterial] = useState(
    mode === "COURSE" ? "PLA" : "PLA",
  );
  const [accuracy, setAccuracy] = useState(
    mode === "COURSE" ? 0.2 : 0.2,
  );
  const [fill, setFill] = useState(25);
  const [support, setSupport] = useState(false);
  const [printSpeed, setPrintSpeed] = useState(60);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showPresets, setShowPresets] = useState(false);

  const applyPreset = (
    preset: "fast" | "standard" | "fine",
  ) => {
    if (preset === "fast") {
      setAccuracy(0.3);
      setFill(25);
      setPrintSpeed(80);
      setSupport(false);
    } else if (preset === "standard") {
      setAccuracy(0.2);
      setFill(50);
      setPrintSpeed(60);
      setSupport(false);
    } else if (preset === "fine") {
      setAccuracy(0.1);
      setFill(75);
      setPrintSpeed(40);
      setSupport(true);
    }
    setShowPresets(false);
  };

  const handleFileUpload = () => {
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
      setStep("PARAMS");
    }, 1500);
  };

  const { base, final, msg, isFree, timeString, supportFree } =
    useMemo(() => {
      const baseMinutes = volume * 0.3;
      const fillFactor = 1 + fill / 100;
      const accuracyFactor =
        accuracy === 0.1 ? 2.0 : accuracy === 0.2 ? 1.0 : 0.7;
      const materialFactor = material === "Resin" ? 1.5 : 1.0;
      const speedFactor = 60 / printSpeed;
      const supportFactor = support ? 1.2 : 1.0;
      const totalMinutes = Math.round(
        baseMinutes *
          fillFactor *
          accuracyFactor *
          materialFactor *
          speedFactor *
          supportFactor,
      );
      const hours = Math.floor(totalMinutes / 60);
      const mins = totalMinutes % 60;
      const timeString =
        hours > 0 ? `${hours}小时${mins}分` : `${mins}分钟`;
      const materialPricePerCm3 =
        material === "PLA"
          ? 0.3
          : material === "ABS"
            ? 0.4
            : 0.8;
      const machineRatePerMin = 0.2;
      let basePrice =
        volume * materialPricePerCm3 +
        totalMinutes * machineRatePerMin;

      // 判断支撑是否免费
      let supportFreeFlag = false;
      if (mode === "COURSE" && user.role === "COURSE") {
        supportFreeFlag = true; // 课程学生支撑免费
      } else if (support) {
        basePrice += 5; // 其他用户支撑额外收费
      }

      let finalPrice = basePrice;
      let message = "";
      let free = false;

      if (mode === "COURSE" && user.role === "COURSE") {
        const validParams =
          material === "PLA" &&
          (accuracy === 0.2 || accuracy === 0.3) &&
          fill <= 50 &&
          volume <= 1000;
        if (validParams && user.quota > 0) {
          finalPrice = 0;
          message = `课程权益已抵扣 (剩余${user.quota}次)`;
          free = true;
        } else {
          finalPrice = basePrice * 0.88;
          message = "超出课程权益限制，转8.8折";
        }
      } else if (
        user.role === "CAMPUS" ||
        user.role === "COURSE"
      ) {
        finalPrice = basePrice * 0.88;
        message = "校园专属 8.8 折";
      }
      return {
        base: basePrice,
        final: finalPrice,
        msg: message,
        isFree: free,
        timeString,
        supportFree: supportFreeFlag,
      };
    }, [
      volume,
      material,
      accuracy,
      fill,
      support,
      printSpeed,
      mode,
      user,
    ]);

  const getOptionStyle = (
    isSelected: boolean,
    isValid: boolean,
  ) => {
    if (!isSelected)
      return "border-gray-200 text-gray-600 bg-white";
    if (mode === "COURSE" && !isValid)
      return "bg-red-50 border-red-500 text-red-600";
    return "bg-blue-50 border-blue-600 text-blue-600";
  };

  if (step === "FILE") {
    return (
      <div className="h-full bg-gray-50 flex flex-col">
        <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
          <button onClick={back}>
            <ChevronLeft />
          </button>
          <h2 className="font-bold text-lg">
            模型上传 ({mode === "COURSE" ? "课程" : "自由"})
          </h2>
        </div>
        <div className="p-4 flex-1 flex flex-col items-center justify-center">
          <div
            onClick={handleFileUpload}
            className="w-full h-64 border-2 border-dashed border-blue-300 bg-blue-50 rounded-2xl flex flex-col items-center justify-center cursor-pointer active:scale-95 transition-transform relative overflow-hidden"
          >
            {analyzing ? (
              <div className="flex flex-col items-center animate-in fade-in">
                <Loader2
                  size={40}
                  className="text-blue-600 animate-spin mb-4"
                />
                <p className="text-blue-800 font-bold">
                  正在解析模型...
                </p>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-4">
                  <Upload size={32} />
                </div>
                <p className="font-bold text-blue-800">
                  点击上传 STL/OBJ/3MF 文件
                </p>
              </>
            )}
          </div>
          {mode === "COURSE" && (
            <div className="mt-6 bg-orange-50 text-orange-700 p-4 rounded-xl text-sm w-full">
              <p className="font-bold mb-1">
                🎓 课程免费标准：
              </p>
              1000cm³内 | PLA | 精度0.2/0.3 | 填充≤50%
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-gray-50 flex flex-col">
      <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
        <button onClick={() => setStep("FILE")}>
          <ChevronLeft />
        </button>
        <h2 className="font-bold text-lg">配置参数</h2>
        <div className="flex-1"></div>
        <button
          onClick={() => setShowPresets(!showPresets)}
          className="text-xs px-3 py-1.5 bg-blue-50 text-blue-600 rounded-full font-medium flex items-center gap-1"
        >
          <Zap size={14} />
          预设
        </button>
      </div>

      {/* 预设方案面板 */}
      {showPresets && (
        <div className="bg-white border-b border-gray-200 p-4 animate-in slide-in-from-top duration-200">
          <p className="text-xs text-gray-500 mb-3">
            快速应用预设方案
          </p>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => applyPreset("fast")}
              className="p-3 bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl text-left active:scale-95 transition-transform"
            >
              <div className="flex items-center gap-1 mb-1">
                <Zap size={14} className="text-green-600" />
                <span className="text-sm font-bold text-green-700">
                  快速
                </span>
              </div>
              <p className="text-xs text-green-600">
                0.3mm・25%
              </p>
            </button>
            <button
              onClick={() => applyPreset("standard")}
              className="p-3 bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl text-left active:scale-95 transition-transform"
            >
              <div className="flex items-center gap-1 mb-1">
                <CheckCircle
                  size={14}
                  className="text-blue-600"
                />
                <span className="text-sm font-bold text-blue-700">
                  标准
                </span>
              </div>
              <p className="text-xs text-blue-600">
                0.2mm・50%
              </p>
            </button>
            <button
              onClick={() => applyPreset("fine")}
              className="p-3 bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-xl text-left active:scale-95 transition-transform"
            >
              <div className="flex items-center gap-1 mb-1">
                <Star size={14} className="text-purple-600" />
                <span className="text-sm font-bold text-purple-700">
                  精细
                </span>
              </div>
              <p className="text-xs text-purple-600">
                0.1mm・75%
              </p>
            </button>
          </div>
        </div>
      )}

      <div className="p-4 flex-1 overflow-y-auto pb-24">
        {/* 3D预览 */}
        <div className="bg-gray-900 rounded-2xl shadow-sm mb-4 h-64 relative overflow-hidden flex items-center justify-center group">
          <div className="w-32 h-32 border-2 border-blue-500/50 rounded-xl flex items-center justify-center relative animate-[spin_10s_linear_infinite]">
            <div className="text-5xl">🧊</div>
          </div>
          <div className="absolute bottom-3 left-4 text-white/90 text-sm font-bold backdrop-blur-md bg-black/20 p-2 rounded-lg">
            Demo_Model.stl
            <span className="block text-xs font-normal opacity-70">
              Vol: {volume} cm³
            </span>
          </div>
        </div>

        {/* 基础参数 */}
        <div className="bg-white p-4 rounded-2xl shadow-sm space-y-5 mb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800">
              基础参数
            </h3>
          </div>

          {/* 材料 */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <label className="text-sm text-gray-500">
                材料
              </label>
              <div className="group relative">
                <Info
                  size={14}
                  className="text-gray-400 cursor-help"
                />
                <div className="hidden group-hover:block absolute left-0 top-6 bg-gray-800 text-white text-xs p-2 rounded-lg w-48 z-10">
                  选择打印材料。PLA适合大多数模型，ABS更耐用，Resin精度最高
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              {["PLA", "ABS", "Resin"].map((m) => (
                <button
                  key={m}
                  onClick={() => setMaterial(m)}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-medium border ${getOptionStyle(material === m, m === "PLA")}`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* 精度 */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <label className="text-sm text-gray-500">
                层高精度 (mm)
              </label>
              <div className="group relative">
                <Info
                  size={14}
                  className="text-gray-400 cursor-help"
                />
                <div className="hidden group-hover:block absolute left-0 top-6 bg-gray-800 text-white text-xs p-2 rounded-lg w-48 z-10">
                  层高越小越精细，但打印时间更长。0.2mm为标准精度
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              {[0.1, 0.2, 0.3].map((a) => (
                <button
                  key={a}
                  onClick={() => setAccuracy(a)}
                  className={`flex-1 py-2.5 rounded-lg text-sm font-medium border ${getOptionStyle(accuracy === a, a === 0.2 || a === 0.3)}`}
                >
                  {a}
                </button>
              ))}
            </div>
          </div>

          {/* 填充率 */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <label className="text-sm text-gray-500">
                填充率
              </label>
              <div className="group relative">
                <Info
                  size={14}
                  className="text-gray-400 cursor-help"
                />
                <div className="hidden group-hover:block absolute left-0 top-6 bg-gray-800 text-white text-xs p-2 rounded-lg w-48 z-10">
                  内部填充密度。25%适合装饰品，75%以上适合功能件
                </div>
              </div>
            </div>
            <div className="w-full bg-gray-100 rounded-lg p-1 flex">
              {[25, 50, 75, 100].map((f) => (
                <button
                  key={f}
                  onClick={() => setFill(f)}
                  className={`flex-1 py-2 rounded-md text-xs font-bold ${fill === f ? (mode === "COURSE" && f > 50 ? "bg-red-500 text-white" : "bg-blue-600 text-white") : "text-gray-500"}`}
                >
                  {f}%
                </button>
              ))}
            </div>
          </div>

          {/* 添加支撑 */}
          <div className="pt-2 border-t border-gray-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <label className="text-sm text-gray-700 font-medium">
                  添加支撑
                </label>
                <div className="group relative">
                  <Info
                    size={14}
                    className="text-gray-400 cursor-help"
                  />
                  <div className="hidden group-hover:block absolute left-0 top-6 bg-gray-800 text-white text-xs p-2 rounded-lg w-48 z-10">
                    为悬空部分添加支撑结构，打印后需手动去除
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSupport(!support)}
                className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${support ? "bg-blue-600" : "bg-gray-300"}`}
              >
                <div
                  className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform duration-200 ${support ? "translate-x-6" : "translate-x-0"}`}
                ></div>
              </button>
            </div>
            {support && (
              <p
                className={`text-xs mt-2 p-2 rounded-lg ${supportFree ? "text-green-600 bg-green-50" : "text-orange-600 bg-orange-50"}`}
              >
                {supportFree
                  ? "✅ 课程学生支撑免费，仅增加20%打印时间"
                  : "⚠️ 支撑结构会增加5元费用和20%打印时间"}
              </p>
            )}
          </div>
        </div>

        {/* 高级设置 */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full p-4 flex items-center justify-between active:bg-gray-50"
          >
            <div className="flex items-center gap-2">
              <Settings size={18} className="text-gray-600" />
              <span className="font-bold text-gray-800">
                高级设置
              </span>
            </div>
            <ChevronRight
              size={18}
              className={`text-gray-400 transition-transform ${showAdvanced ? "rotate-90" : ""}`}
            />
          </button>

          {showAdvanced && (
            <div className="p-4 pt-0 space-y-4 border-t border-gray-100 animate-in slide-in-from-top duration-200">
              {/* 打印速度 */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm text-gray-700">
                    打印速度
                  </label>
                  <span className="text-sm font-bold text-blue-600">
                    {printSpeed} mm/s
                  </span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  step="10"
                  value={printSpeed}
                  onChange={(e) =>
                    setPrintSpeed(Number(e.target.value))
                  }
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <div className="flex justify-between text-xs text-gray-400 mt-1">
                  <span>慢速</span>
                  <span>快速</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 底部按钮 */}
      <div className="bg-white p-4 border-t pb-8">
        <div className="flex justify-between items-end mb-2">
          <div>
            <p className="text-xs text-gray-400 line-through">
              ¥{base.toFixed(2)}
            </p>
            <div className="flex items-end gap-2">
              <p
                className={`text-2xl font-bold ${isFree ? "text-green-600" : "text-red-500"}`}
              >
                {isFree ? "免费" : `¥${final.toFixed(2)}`}
              </p>
              <span className="text-xs text-gray-500 mb-1.5">
                约 {timeString}
              </span>
            </div>
          </div>
          {msg && (
            <span
              className={`text-xs px-2 py-1 rounded ${isFree ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-600"}`}
            >
              {msg}
            </span>
          )}
        </div>
        <button
          onClick={() => {
            const newTask: Task = {
              id: `T${Date.now()}`,
              printerId: `P-${Math.floor(Math.random() * 100) + 100}`,
              name: "Demo_Model.stl",
              thumb: "🧊",
              status: "QUEUED",
              progress: 0,
              info: "前方 3 人",
              timeLeft: 60,
            };
            setTasks((prev) => [newTask, ...prev]);
            if (isFree)
              setUser({ ...user, quota: user.quota - 1 });
            switchTab("TAB_TASK");
          }}
          className="w-full bg-blue-600 text-white py-3 rounded-full font-bold shadow-lg active:scale-95 transition-transform"
        >
          {isFree ? "免费打印" : "确认下单"}
        </button>
      </div>
    </div>
  );
};

// 3. TaskList
const TaskList = ({
  tasks,
  navigate,
  onDelete,
}: {
  tasks: Task[];
  navigate: (view: string) => void;
  onDelete: (id: string) => void;
}) => (
  <div className="pb-24 bg-gray-50 min-h-screen">
    <div className="bg-white pt-12 pb-4 px-4 sticky top-0 z-10 shadow-sm">
      <h1 className="text-xl font-bold">打印任务</h1>
    </div>
    <div className="p-4 space-y-4">
      {tasks.length === 0 ? (
        <div className="text-center text-gray-400 py-12">
          暂无任务
        </div>
      ) : (
        tasks.map((task) => (
          <div
            key={task.id}
            onClick={() => navigate(`MONITOR_${task.id}`)}
            className={`bg-white p-4 rounded-2xl shadow-sm border active:scale-95 transition-transform relative overflow-hidden group ${task.status === "PRINTING" ? "border-blue-200 ring-2 ring-blue-50" : "border-gray-100"}`}
          >
            <div className="flex gap-4 relative z-10 pr-8">
              <div
                className={`w-20 h-20 rounded-xl flex items-center justify-center text-3xl ${task.status === "EXCEPTION" ? "bg-red-50 text-red-500" : "bg-gray-100 text-gray-600"}`}
              >
                {task.thumb}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-gray-800">
                      {task.name}
                    </h3>
                    <div className="text-xs text-gray-400 mt-0.5 bg-gray-50 inline-block px-1 rounded">
                      ID: {task.printerId}
                    </div>
                  </div>
                  <span
                    className={`text-xs px-2 py-1 rounded font-medium whitespace-nowrap ml-2 ${task.status === "PRINTING" ? "bg-blue-100 text-blue-600" : task.status === "QUEUED" ? "bg-orange-100 text-orange-600" : task.status === "COMPLETED" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"}`}
                  >
                    {TASK_STATUS_MAP[task.status]}
                  </span>
                </div>
                <div className="mt-3">
                  {task.status === "PRINTING" ? (
                    <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-500 transition-all duration-300"
                        style={{ width: `${task.progress}%` }}
                      ></div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 mt-2">
                      {task.info}
                    </p>
                  )}
                </div>
              </div>
            </div>
            {task.status !== "PRINTING" && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(task.id);
                }}
                className="absolute top-0 right-0 p-3 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-bl-2xl"
              >
                <Trash2 size={18} />
              </button>
            )}
          </div>
        ))
      )}
    </div>
  </div>
);

// 4. CustomFormPage
const CustomFormPage = ({
  back,
  setNotifications,
  setSuccessModal,
}: {
  back: () => void;
  setNotifications: React.Dispatch<
    React.SetStateAction<Notification[]>
  >;
  setSuccessModal: (state: any) => void;
}) => {
  const [contact, setContact] = useState("");
  const [size, setSize] = useState("medium");
  const [materialType, setMaterialType] = useState("hard");

  const steps = [
    { title: "提交需求", icon: FileText },
    { title: "人工审核", icon: User },
    { title: "确认报价", icon: FileText },
    { title: "生产制作", icon: Printer },
    { title: "交付", icon: Package },
  ];

  const handleSubmit = () => {
    setNotifications((prev) => [
      {
        id: `N_${Date.now()}`,
        title: "定制需求已提交",
        content:
          "您的定制打印需求已成功提交，单号：REQ-" +
          Date.now().toString().slice(-4) +
          "，设计师将在24小时内联系您。",
        time: new Date().toLocaleTimeString(),
        read: false,
        type: "CUSTOM",
      },
      ...prev,
    ]);
    setSuccessModal({
      isOpen: true,
      title: "提交成功",
      message: "感谢您的需求，设计师将尽快与您联系。",
      icon: "🎉",
    });
    setTimeout(() => back(), 1500);
  };

  return (
    <div className="h-full bg-gray-50 flex flex-col">
      <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
        <button onClick={back}>
          <ChevronLeft />
        </button>
        <h2 className="font-bold text-lg">定制打印需求</h2>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <div className="bg-white p-4 rounded-2xl shadow-sm">
          <h3 className="font-bold text-sm mb-4">服务流程</h3>
          <div className="flex justify-between items-center text-xs text-gray-500 relative">
            <div className="absolute top-3 left-4 right-4 h-0.5 bg-gray-100 -z-0"></div>
            {steps.map((s, i) => (
              <div
                key={i}
                className="flex flex-col items-center bg-white z-10 px-1"
              >
                <div className="w-6 h-6 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-1">
                  <s.icon size={12} />
                </div>
                <span>{s.title}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl shadow-sm space-y-5">
          <div>
            <label className="block text-sm font-bold mb-2 flex items-center gap-2">
              <Phone size={14} /> 联系方式
            </label>
            <input
              value={contact}
              onChange={(e) => setContact(e.target.value)}
              className="w-full bg-gray-50 p-3 rounded-lg text-sm border border-gray-200 focus:outline-blue-500"
              placeholder="手机号 / 微信号"
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2 flex items-center gap-2">
              <Ruler size={14} /> 预计模型大小 (最长边)
            </label>
            <div className="flex bg-gray-50 p-1 rounded-lg">
              {[
                { id: "small", label: "< 10cm", desc: "小件" },
                {
                  id: "medium",
                  label: "10-20cm",
                  desc: "中件",
                },
                { id: "large", label: "> 20cm", desc: "大件" },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSize(opt.id)}
                  className={`flex-1 py-2 rounded-md text-xs transition-all flex flex-col items-center ${size === opt.id ? "bg-white shadow text-blue-600 font-bold" : "text-gray-500"}`}
                >
                  <span>{opt.label}</span>
                  <span className="scale-95 opacity-70">
                    {opt.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2 flex items-center gap-2">
              <Layers size={14} /> 材料倾向
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                {
                  id: "hard",
                  label: "硬塑料",
                  desc: "PLA/ABS",
                },
                { id: "soft", label: "软胶", desc: "TPU" },
                {
                  id: "resin",
                  label: "精细树脂",
                  desc: "SLA/DLP",
                },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMaterialType(m.id)}
                  className={`p-2 rounded-lg border text-left ${materialType === m.id ? "border-blue-500 bg-blue-50" : "border-gray-200"}`}
                >
                  <div
                    className={`text-sm font-bold ${materialType === m.id ? "text-blue-700" : "text-gray-700"}`}
                  >
                    {m.label}
                  </div>
                  <div className="text-xs text-gray-400 mt-0.5">
                    {m.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold mb-2 flex items-center gap-2">
              <FileText size={14} /> 详细需求
            </label>
            <textarea
              className="w-full bg-gray-50 p-3 rounded-lg text-sm h-24 border border-gray-200 focus:outline-blue-500"
              placeholder="请描述物品用途、外观要求、是否需要上色等..."
            />
          </div>

          <div>
            <label className="block text-sm font-bold mb-2 flex items-center gap-2">
              <ImageIcon size={14} /> 参考图 / 草图
            </label>
            <div className="w-24 h-24 bg-gray-50 rounded-lg flex flex-col items-center justify-center border border-dashed border-gray-300 text-gray-400 hover:bg-gray-100 transition-colors">
              <Upload size={20} />
              <span className="text-xs mt-1">上传</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 bg-white border-t pb-8 safe-area-bottom">
        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 text-white py-3 rounded-full font-bold shadow-lg shadow-blue-200"
        >
          提交需求
        </button>
      </div>
    </div>
  );
};

// 5. MonitorPage
const MonitorPage = ({
  taskId,
  tasks,
  setTasks,
  back,
  onDelete,
}: {
  taskId: string;
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
  back: () => void;
  onDelete: (id: string) => void;
}) => {
  const task = tasks.find((t) => t.id === taskId);
  const [showQR, setShowQR] = useState(false);
  if (!task) return null;
  return (
    <div className="h-full bg-gray-900 text-white flex flex-col relative">
      <div className="p-4 pt-12 flex items-center gap-4">
        <button onClick={back}>
          <ChevronLeft className="text-white" />
        </button>
        <h2 className="font-bold text-lg">实时监控</h2>
        {/* Delete Button for non-printing tasks */}
        {task.status !== "PRINTING" && (
          <button
            onClick={() => {
              onDelete(task.id);
              back();
            }}
            className="ml-auto text-red-400 hover:text-red-300"
          >
            <Trash2 size={20} />
          </button>
        )}
      </div>
      <div className="flex-1 flex flex-col items-center justify-center p-8 relative">
        <div
          className={`w-64 h-64 border-4 ${task.status === "EXCEPTION" ? "border-red-500" : "border-blue-500/30"} rounded-full flex items-center justify-center relative ${task.status === "PRINTING" ? "animate-pulse" : ""}`}
        >
          <div className="text-6xl">{task.thumb}</div>
        </div>
        <div className="mt-8 text-center">
          <h3 className="text-2xl font-bold">{task.name}</h3>
          <div className="text-white/70 mt-2 font-mono">
            ID: {task.printerId}
          </div>
        </div>
        <p className="mt-4 font-medium text-blue-400">
          {task.status === "PRINTING"
            ? `打印中 ${task.progress}%`
            : TASK_STATUS_MAP[task.status]}
        </p>
      </div>
      <div className="bg-gray-800 rounded-t-3xl p-6 pb-12">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-700 p-3 rounded-xl text-center">
            <div className="text-xl font-bold">
              {task.status === "COMPLETED"
                ? "0"
                : task.timeLeft || "--"}
            </div>
            <div className="text-xs text-gray-400">
              剩余分钟
            </div>
          </div>
          <div className="bg-gray-700 p-3 rounded-xl text-center">
            <div className="text-xl font-bold">
              {task.temps?.nozzle || "--"}°
            </div>
            <div className="text-xs text-gray-400">喷头</div>
          </div>
          <div className="bg-gray-700 p-3 rounded-xl text-center">
            <div className="text-xl font-bold">
              {task.temps?.bed || "--"}°
            </div>
            <div className="text-xs text-gray-400">热床</div>
          </div>
        </div>
        {task.status === "PRINTING" && (
          <button
            onClick={() =>
              setTasks((prev) =>
                prev.map((t) =>
                  t.id === taskId
                    ? { ...t, status: "EXCEPTION" }
                    : t,
                ),
              )
            }
            className="w-full py-3 bg-red-500/20 text-red-500 rounded-full font-bold"
          >
            模拟故障
          </button>
        )}
        {task.status === "COMPLETED" && (
          <button
            onClick={() => setShowQR(true)}
            className="w-full py-3 bg-green-500 text-white rounded-full font-bold"
          >
            出示取件码
          </button>
        )}
        {task.status === "EXCEPTION" && (
          <div className="flex gap-3">
            <button
              onClick={() => {
                setTasks((prev) =>
                  prev.map((t) =>
                    t.id === taskId
                      ? {
                          ...t,
                          status: "QUEUED",
                          progress: 0,
                          info: "重打排队中",
                        }
                      : t,
                  ),
                );
              }}
              className="flex-1 py-3 bg-blue-600 text-white rounded-full font-bold"
            >
              一键重打
            </button>
            <button className="flex-1 py-3 bg-gray-700 text-white rounded-full font-bold">
              联系客服
            </button>
          </div>
        )}
      </div>
      {showQR && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 text-black relative">
            <QrCode size={160} />
            <button
              onClick={() => setShowQR(false)}
              className="absolute top-2 right-2"
            >
              <X />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// 6. SettingsIndex
const SettingsIndex = ({ back, navigate }: any) => (
  <div className="h-full bg-gray-50 flex flex-col">
    <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
      <button onClick={back}>
        <ChevronLeft />
      </button>
      <h2 className="font-bold text-lg">设置</h2>
    </div>
    <div className="p-4 space-y-4">
      <div className="bg-white rounded-xl overflow-hidden shadow-sm">
        <div
          className="flex items-center p-4 border-b active:bg-gray-50"
          onClick={() => navigate("USER_INFO")}
        >
          <User size={20} className="mr-3" />
          <span className="flex-1">个人信息</span>
          <ChevronRight size={16} />
        </div>
        <div
          className="flex items-center p-4 active:bg-gray-50"
          onClick={() => navigate("ADDRESS")}
        >
          <MapPin size={20} className="mr-3" />
          <span className="flex-1">收货地址</span>
          <ChevronRight size={16} />
        </div>
      </div>
      <button className="w-full py-3 bg-white text-red-500 rounded-xl font-medium shadow-sm flex items-center justify-center gap-2">
        <LogOut size={18} /> 退出登录
      </button>
    </div>
  </div>
);

// 7. AddressPage
const AddressPage = ({ user, back }: any) => (
  <div className="h-full bg-gray-50 flex flex-col">
    <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
      <button onClick={back}>
        <ChevronLeft />
      </button>
      <h2 className="font-bold text-lg">收货地址</h2>
    </div>
    <div className="p-4 space-y-3">
      {user.addresses.map((addr: Address) => (
        <div
          key={addr.id}
          className="bg-white p-4 rounded-xl shadow-sm"
        >
          <div className="font-bold">
            {addr.name} {addr.phone}
          </div>
          <div className="text-sm text-gray-500">
            {addr.detail}
          </div>
        </div>
      ))}
      <button className="w-full py-3 bg-green-50 text-green-700 rounded-xl font-bold">
        微信导入
      </button>
    </div>
  </div>
);

// 8. UserInfoPage
const UserInfoPage = ({ user, back }: any) => (
  <div className="h-full bg-gray-50 flex flex-col">
    <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
      <button onClick={back}>
        <ChevronLeft />
      </button>
      <h2 className="font-bold text-lg">个人信息</h2>
    </div>
    <div className="p-4">
      <div className="bg-white rounded-xl p-4 flex justify-between">
        <span>昵称</span>
        <span>{user.name}</span>
      </div>
    </div>
  </div>
);

// 9. OrderListPage (Updated with Post-Purchase Actions)
const OrderListPage = ({
  shopOrders,
  back,
  navigate,
}: {
  shopOrders: Order[];
  back: () => void;
  navigate: (view: string) => void;
}) => {
  return (
    <div className="h-full bg-gray-50 flex flex-col">
      <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
        <button onClick={back}>
          <ChevronLeft />
        </button>
        <h2 className="font-bold text-lg">商城订单</h2>
      </div>
      <div className="p-4 space-y-4">
        {shopOrders.map((order) => {
          // Check if order has virtual items (simplified check)
          const hasVirtual = order.items.some(
            (item) => item.type !== "PHYSICAL",
          );
          return (
            <div
              key={order.id}
              className="bg-white p-4 rounded-xl shadow-sm"
            >
              <div className="flex justify-between items-center mb-3 border-b border-gray-50 pb-2">
                <span className="text-xs text-gray-500">
                  订单号 {order.id}
                </span>
                <span className="text-xs font-bold text-blue-600">
                  {ORDER_STATUS_MAP[order.status]}
                </span>
              </div>
              <div className="mb-3 space-y-2">
                {order.items.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex justify-between text-sm"
                  >
                    <span className="text-gray-800">
                      {item.name} x{item.quantity}
                    </span>
                    {item.selectedAddOn && (
                      <span className="text-xs text-purple-500 bg-purple-50 px-1 rounded ml-2">
                        + {item.selectedAddOn.name}
                      </span>
                    )}
                  </div>
                ))}
                <div className="text-xs text-gray-400 mt-1">
                  {order.date}
                </div>
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className="font-bold text-lg">
                  ¥{order.total.toFixed(2)}
                </span>
                <div className="flex gap-2">
                  {hasVirtual && (
                    <>
                      <button
                        onClick={() =>
                          alert("模型文件已发送至您的邮箱")
                        }
                        className="text-xs border border-gray-200 px-3 py-1.5 rounded-full flex items-center gap-1"
                      >
                        <Download size={12} /> 下载
                      </button>
                      <button
                        onClick={() => navigate("UPLOAD_FREE")}
                        className="text-xs bg-blue-50 text-blue-600 px-3 py-1.5 rounded-full flex items-center gap-1"
                      >
                        <Printer size={12} /> 去打印
                      </button>
                    </>
                  )}
                  {!hasVirtual && (
                    <button className="text-xs border px-3 py-1.5 rounded-full">
                      查看物流
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// 10. CheckoutPage (Updated with Post-Purchase Modal)
const CheckoutPage = ({
  cart,
  user,
  back,
  navigate,
  setShopOrders,
  setTasks,
  setCart,
  switchTab,
}: any) => {
  const [isPaying, setIsPaying] = useState(false);
  const [showSuccessModal, setShowSuccessModal] =
    useState(false);
  const [virtualItemsInOrder, setVirtualItemsInOrder] =
    useState<CartItem[]>([]);

  const total = cart.reduce(
    (sum: number, p: CartItem) =>
      sum +
      (p.price + (p.selectedAddOn?.price || 0)) * p.quantity,
    0,
  );
  const discount =
    user.role === "CAMPUS" || user.role === "COURSE"
      ? total * 0.12
      : 0;
  const final = total - discount;
  const defaultAddr = user.addresses.find(
    (a: Address) => a.isDefault,
  );

  const handlePay = () => {
    if (
      cart.some((p: Product) => p.type === "PHYSICAL") &&
      !defaultAddr
    ) {
      alert("订单包含实体商品，请先选择收货地址！");
      return;
    }

    setIsPaying(true);

    setTimeout(() => {
      // Create Order
      const newOrder: Order = {
        id: `ORD_${Date.now()}`,
        status: "PENDING",
        total: final,
        items: [...cart], // Store full cart items
        date: new Date().toLocaleDateString(),
      };
      setShopOrders((prev: Order[]) => [newOrder, ...prev]);

      // Separate virtual items for the success modal
      const virtualItems = cart.filter(
        (p: CartItem) => p.type !== "PHYSICAL",
      );
      setVirtualItemsInOrder(virtualItems);

      setCart([]);
      setIsPaying(false);
      setShowSuccessModal(true);
    }, 1500);
  };

  return (
    <div className="h-full bg-gray-50 flex flex-col relative">
      <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
        <button onClick={back}>
          <ChevronLeft />
        </button>
        <h2 className="font-bold text-lg">订单确认</h2>
      </div>
      <div className="p-4 flex-1 overflow-y-auto">
        <div
          onClick={() => navigate("ADDRESS")}
          className="bg-white p-4 rounded-xl shadow-sm mb-4 flex justify-between items-center"
        >
          {defaultAddr ? (
            <div>
              <div className="font-bold">
                {defaultAddr.name}
              </div>
              <div className="text-sm text-gray-500">
                {defaultAddr.detail}
              </div>
            </div>
          ) : (
            <span className="text-red-500">选择地址</span>
          )}
          <ChevronRight />
        </div>
        <div className="bg-white p-4 rounded-xl shadow-sm space-y-2">
          {cart.map((item: CartItem, idx: number) => (
            <div
              key={idx}
              className="flex justify-between items-center"
            >
              <div>
                <span className="block">
                  {item.name} x{item.quantity}
                </span>
                {item.selectedAddOn && (
                  <span className="text-xs text-purple-500">
                    + {item.selectedAddOn.name}
                  </span>
                )}
              </div>
              <span>
                ¥
                {(
                  (item.price +
                    (item.selectedAddOn?.price || 0)) *
                  item.quantity
                ).toFixed(2)}
              </span>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-white p-4 border-t pb-8 flex justify-between items-center">
        <div>
          <div className="text-sm text-gray-500">
            共{" "}
            {cart.reduce(
              (s: number, i: CartItem) => s + i.quantity,
              0,
            )}{" "}
            件
          </div>
          <div className="text-xl font-bold text-red-600">
            ¥{final.toFixed(2)}
          </div>
        </div>
        <button
          disabled={isPaying}
          onClick={handlePay}
          className="bg-blue-600 text-white px-8 py-3 rounded-full font-bold shadow-lg flex items-center gap-2 disabled:bg-gray-400"
        >
          {isPaying ? (
            <Loader2 className="animate-spin" size={20} />
          ) : (
            "立即支付"
          )}
        </button>
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="absolute inset-0 bg-black/50 z-50 flex items-center justify-center p-6 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-2xl p-6 text-center">
            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} />
            </div>
            <h3 className="text-xl font-bold mb-2">支付成功</h3>
            <p className="text-gray-500 text-sm mb-6">
              {virtualItemsInOrder.length > 0
                ? `成功购买 ${virtualItemsInOrder.length} 个数字模型/服务，您可以：`
                : "实体商品将尽快发货。"}
            </p>

            {virtualItemsInOrder.length > 0 && (
              <div className="space-y-3 mb-6">
                <button
                  onClick={() => {
                    setShowSuccessModal(false);
                    navigate("UPLOAD_FREE");
                  }}
                  className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold flex items-center justify-center gap-2"
                >
                  <Printer size={18} /> 直接打印
                </button>
                <button
                  onClick={() => {
                    alert("下载链接已发送至邮箱");
                  }}
                  className="w-full py-3 bg-blue-50 text-blue-600 rounded-xl font-bold flex items-center justify-center gap-2"
                >
                  <Download size={18} /> 下载模型
                </button>
              </div>
            )}

            <button
              onClick={() => {
                setShowSuccessModal(false);
                switchTab("TAB_SHOP");
              }}
              className="text-gray-400 text-sm"
            >
              返回商城
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// 11. MeProfile
const MeProfile = ({
  user,
  setUser,
  setShowGlobalAuth,
  navigate,
  switchTab,
  setShowLoginSheet,
}: any) => {
  return (
    <div className="pb-24 bg-gray-50 min-h-screen">
      <div className="pt-20 pb-16 px-6 text-white relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1610599976450-a19bf51efe2f?q=80&w=1074&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            alt="Profile Background"
            className="w-full h-full object-cover"
          />
          {/* Dark overlay for better text readability */}
          <div className="absolute inset-0 bg-gradient-to-b from-blue-900/60 via-blue-800/70 to-blue-700/80"></div>
        </div>
        <div
          onClick={() =>
            user.name === "未登录用户" &&
            setShowLoginSheet(true)
          }
          className={`flex items-center gap-4 relative z-10 ${user.name === "未登录用户" ? "cursor-pointer active:opacity-80" : ""}`}
        >
          <img
            src={user.avatar}
            className="w-16 h-16 rounded-full border-2 border-white/50 bg-white"
          />
          <div>
            <h2 className="text-xl font-bold">{user.name}</h2>
            <span className="text-xs bg-white/20 px-2 py-1 rounded mt-1 inline-block">
              {user.role === "GUEST"
                ? user.name === "未登录用户"
                  ? "普通用户 (点击登录)"
                  : "普通用户 (未认证)"
                : user.role === "CAMPUS"
                  ? "校园学生"
                  : "课程学生"}
            </span>
          </div>
          <Settings
            onClick={(e) => {
              e.stopPropagation();
              navigate("SETTINGS");
            }}
            className="ml-auto text-white/80 cursor-pointer"
          />
        </div>
      </div>
      <div className="px-4 -mt-8 relative z-20">
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-4">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-gray-800">
              我的权益
            </h3>
            {user.role === "GUEST" ? (
              user.name === "未登录用户" ? (
                <button
                  onClick={() => setShowLoginSheet(true)}
                  className="text-xs bg-blue-600 text-white px-4 py-1.5 rounded-full font-bold shadow-md shadow-blue-200 animate-pulse"
                >
                  立即登录
                </button>
              ) : (
                <button
                  onClick={() => setShowGlobalAuth(true)}
                  className="text-xs bg-blue-600 text-white px-4 py-1.5 rounded-full font-bold shadow-md shadow-blue-200 animate-pulse"
                >
                  立即认证
                </button>
              )
            ) : (
              <button
                onClick={() => setShowGlobalAuth(true)}
                className="text-xs text-blue-600 flex items-center gap-1 bg-blue-50 px-2 py-1 rounded-full"
              >
                <RefreshCw size={12} /> 重新验证
              </button>
            )}
          </div>
          <div className="flex">
            <div className="flex-1 text-center border-r border-gray-100">
              <div className="text-2xl font-bold text-gray-800">
                {user.role === "COURSE" ? user.quota : "-"}{" "}
                <span className="text-xs font-normal text-gray-500">
                  次
                </span>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                剩余免费额度
              </div>
            </div>
            <div className="flex-1 text-center">
              <div className="text-2xl font-bold text-gray-800">
                {user.role === "GUEST" ? "-" : "8.8"}{" "}
                <span className="text-xs font-normal text-gray-500">
                  折
                </span>
              </div>
              <div className="text-xs text-gray-500 mt-1">
                全场通用折扣
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {[
            {
              icon: FileText,
              label: "我的打印任务",
              action: () => switchTab("TAB_TASK"),
            },
            {
              icon: ShoppingCart,
              label: "商城订单",
              action: () => navigate("ORDER_LIST"),
            },
            {
              icon: MapPin,
              label: "收货地址管理",
              action: () => navigate("ADDRESS"),
            },
          ].map((item, i) => (
            <div
              key={i}
              onClick={item.action}
              className="flex items-center p-4 border-b border-gray-50 last:border-0 active:bg-gray-50"
            >
              <item.icon
                size={20}
                className="text-gray-400 mr-3"
              />
              <span className="flex-1 text-sm text-gray-700">
                {item.label}
              </span>
              <ChevronRight
                size={16}
                className="text-gray-300"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 12. NotificationList
const NotificationList = ({
  notifications,
  back,
}: {
  notifications: Notification[];
  back: () => void;
}) => {
  return (
    <div className="h-full bg-gray-50 flex flex-col">
      <div className="bg-white p-4 pt-12 shadow-sm flex items-center gap-4">
        <button onClick={back}>
          <ChevronLeft />
        </button>
        <h2 className="font-bold text-lg">消息中心</h2>
      </div>
      <div className="p-4 space-y-3">
        {notifications.length === 0 ? (
          <div className="text-center text-gray-400 py-10">
            暂无消息
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              className="bg-white p-4 rounded-xl shadow-sm"
            >
              <div className="flex justify-between mb-2">
                <span className="font-bold text-sm text-gray-900">
                  {n.title}
                </span>
                <span className="text-xs text-gray-400">
                  {n.time}
                </span>
              </div>
              <p className="text-sm text-gray-600">
                {n.content}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

// 13. PrintHome
const PrintHome = ({
  user,
  navigate,
  setShowLoginSheet,
  setShowGlobalAuth,
  lbsInfo,
}: any) => {
  const handleCourseClick = () => {
    if (user.role === "COURSE") {
      navigate("UPLOAD_COURSE");
    } else if (user.name === "未登录用户") {
      // 未登录：引导登录
      setShowLoginSheet(true);
    } else if (user.role === "CAMPUS") {
      // 已认证为校园学生，但需要课程权限
      alert(
        "课程作业打印需要课程学生权限，请重新认证为课程学生",
      );
      setShowGlobalAuth(true);
    } else {
      // 已登录但未认证：引导身份绑定
      setShowGlobalAuth(true);
    }
  };

  return (
    <div className="pb-24">
      <CustomNavBar
        university={lbsInfo.name}
        status={lbsInfo.status}
        onMsg={() => navigate("NOTIFICATION_LIST")}
        onMap={() => navigate("MAP_PAGE")}
        unreadCount={0}
      />
      <BannerCarousel />
      <div className="px-4 mt-6 grid gap-4">
        <div
          onClick={handleCourseClick}
          className="bg-white p-5 rounded-2xl shadow-sm border border-blue-100 relative overflow-hidden active:scale-95 transition-all"
        >
          <div className="absolute top-0 right-0 bg-blue-600 text-white text-xs px-3 py-1 rounded-bl-xl font-medium">
            课程专属 · 免费
          </div>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-2xl">
              🎓
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-800">
                课程作业打印
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                PLA | 0.2/0.3mm | ≤1000cm³
              </p>
            </div>
          </div>
        </div>
        <div
          onClick={() => navigate("UPLOAD_FREE")}
          className="bg-white p-5 rounded-2xl shadow-sm active:scale-95 transition-all"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center text-2xl">
              🚀
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-800">
                自由体验打印
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                不限材料 | 校园8.8折
              </p>
            </div>
          </div>
        </div>
        <div
          onClick={() => navigate("CUSTOM_FORM")}
          className="bg-white p-5 rounded-2xl shadow-sm active:scale-95 transition-all"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center text-2xl">
              🎨
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-800">
                定制打印
              </h3>
              <p className="text-xs text-gray-500 mt-1">
                无模型 | 设计师服务
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [viewStack, setViewStack] = useState<string[]>([
    "TAB_PRINT",
  ]);
  const [showGlobalAuth, setShowGlobalAuth] = useState(false);
  const [showLoginSheet, setShowLoginSheet] = useState(false);

  // Success Modal states
  const [successModal, setSuccessModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    icon?: string;
  }>({
    isOpen: false,
    title: "",
    message: "",
    icon: "✨",
  });

  // Delete Confirmation Modal states
  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    taskId: string | null;
  }>({
    isOpen: false,
    taskId: null,
  });

  const [user, setUser] = useState<UserProfile>({
    name: "未登录用户",
    role: "GUEST", // Default Role: GUEST
    quota: 0,
    avatar:
      "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix",
    addresses: [
      {
        id: "addr1",
        name: "小明",
        phone: "13800138000",
        detail: "四川大学(望江) 西五舍 302",
        tag: "宿舍",
        isDefault: true,
      },
    ],
  });

  const [notifications, setNotifications] = useState<
    Notification[]
  >([
    {
      id: "n1",
      title: "欢迎使用",
      content: "欢迎来到高校3D打印平台，新手请查看帮助文档。",
      time: "10:00",
      read: false,
      type: "SYSTEM",
    },
  ]);

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "T8821",
      printerId: "P-105",
      name: "IronMan_Helm.stl",
      thumb: "🧊",
      status: "PRINTING",
      progress: 45,
      info: "剩余 40m",
      temps: { nozzle: 210, bed: 60 },
      timeLeft: 40,
    },
    {
      id: "T8822",
      printerId: "P-202",
      name: "Test_Block.stl",
      thumb: "🧊",
      status: "QUEUED",
      progress: 0,
      info: "前方 2 人",
      temps: { nozzle: 25, bed: 25 },
      timeLeft: 60,
    },
  ]);

  const [shopOrders, setShopOrders] = useState<Order[]>([
    {
      id: "ORD_001",
      status: "SHIPPED",
      total: 129,
      items: [
        {
          id: "p3",
          name: "桌面台灯",
          price: 129,
          quantity: 1,
          type: "PHYSICAL",
          image: Images.products.DESK_LAMP,
          category: "成品",
          desc: "",
        },
      ],
      date: "2024-02-01",
    },
  ]);

  const [cart, setCart] = useState<CartItem[]>([]);
  const [lbsInfo, setLbsInfo] = useState({
    name: "四川大学(望江校区)",
    status: "营业中",
  });

  // Task Dynamic Data Simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setTasks((prevTasks) =>
        prevTasks.map((task) => {
          if (task.status === "PRINTING") {
            const newProgress = Math.min(
              task.progress + 1,
              100,
            );
            const isFinished = newProgress >= 100;
            return {
              ...task,
              progress: newProgress,
              status: isFinished ? "COMPLETED" : "PRINTING",
              info: isFinished
                ? "打印完成"
                : `剩余 ${Math.max((task.timeLeft || 1) - 1, 0)}m`,
              timeLeft: Math.max((task.timeLeft || 1) - 1, 0),
              temps: {
                nozzle: 210 + Math.floor(Math.random() * 5) - 2,
                bed: 60 + Math.floor(Math.random() * 3) - 1,
              },
            };
          } else if (task.status === "QUEUED") {
            // Auto start queued tasks for demo if not printing (simplified)
            if (Math.random() > 0.9)
              return {
                ...task,
                status: "PRINTING",
                progress: 0,
              };
          }
          return task;
        }),
      );
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setTimeout(() => {
      const randomUni =
        SICHUAN_UNIVERSITIES[
          Math.floor(
            Math.random() * SICHUAN_UNIVERSITIES.length,
          )
        ];
      setLbsInfo({ name: randomUni, status: "营业中" });
    }, 1000);
  }, []);

  const navigate = (view: string) => {
    setViewStack((prev) => [...prev, view]);
  };
  const back = () =>
    setViewStack((prev) =>
      prev.length > 1 ? prev.slice(0, -1) : prev,
    );
  const switchTab = (tab: string) => setViewStack([tab]);
  const currentView = viewStack[viewStack.length - 1];

  const handleDeleteTask = (id: string) => {
    setDeleteModal({ isOpen: true, taskId: id });
  };

  const confirmDeleteTask = () => {
    if (deleteModal.taskId) {
      setTasks((prev) =>
        prev.filter((t) => t.id !== deleteModal.taskId),
      );
      setDeleteModal({ isOpen: false, taskId: null });
    }
  };

  const renderView = () => {
    if (currentView === "TAB_PRINT")
      return (
        <PrintHome
          user={user}
          navigate={navigate}
          setShowLoginSheet={setShowLoginSheet}
          setShowGlobalAuth={setShowGlobalAuth}
          lbsInfo={lbsInfo}
        />
      );
    if (currentView === "TAB_TASK")
      return (
        <TaskList
          tasks={tasks}
          navigate={navigate}
          onDelete={handleDeleteTask}
        />
      );
    if (currentView === "TAB_SHOP")
      return (
        <ShopList
          cart={cart}
          setCart={setCart}
          navigate={navigate}
        />
      );
    if (currentView === "TAB_ME")
      return (
        <MeProfile
          user={user}
          setUser={setUser}
          setShowGlobalAuth={setShowGlobalAuth}
          navigate={navigate}
          switchTab={switchTab}
          setShowLoginSheet={setShowLoginSheet}
        />
      );

    if (currentView === "UPLOAD_COURSE")
      return (
        <UploadPage
          mode="COURSE"
          user={user}
          setUser={setUser}
          setTasks={setTasks}
          switchTab={switchTab}
          back={back}
        />
      );
    if (currentView === "UPLOAD_FREE")
      return (
        <UploadPage
          mode="FREE"
          user={user}
          setUser={setUser}
          setTasks={setTasks}
          switchTab={switchTab}
          back={back}
        />
      );
    if (currentView === "CUSTOM_FORM")
      return (
        <CustomFormPage
          back={back}
          setNotifications={setNotifications}
          setSuccessModal={setSuccessModal}
        />
      );
    if (currentView === "CHECKOUT")
      return (
        <CheckoutPage
          cart={cart}
          user={user}
          back={back}
          navigate={navigate}
          setShopOrders={setShopOrders}
          setTasks={setTasks}
          setCart={setCart}
          switchTab={switchTab}
        />
      );
    if (currentView === "ADDRESS")
      return <AddressPage user={user} back={back} />;
    if (currentView === "SETTINGS")
      return <SettingsIndex back={back} navigate={navigate} />;
    if (currentView === "USER_INFO")
      return <UserInfoPage user={user} back={back} />;
    if (currentView === "ORDER_LIST")
      return (
        <OrderListPage
          shopOrders={shopOrders}
          back={back}
          navigate={navigate}
        />
      );
    if (currentView === "NOTIFICATION_LIST")
      return (
        <NotificationList
          notifications={notifications}
          back={back}
        />
      );
    if (currentView?.startsWith("MONITOR_"))
      return (
        <MonitorPage
          taskId={currentView.replace("MONITOR_", "")}
          tasks={tasks}
          setTasks={setTasks}
          back={back}
          onDelete={handleDeleteTask}
        />
      );
    if (currentView === "MAP_PAGE")
      return (
        <MapPage
          back={back}
          info={lbsInfo}
          setInfo={setLbsInfo}
        />
      );

    return <div>Not Found</div>;
  };

  return (
    <div className="max-w-md mx-auto h-screen bg-gray-50 flex flex-col font-sans overflow-hidden border-x border-gray-200">
      <div className="flex-1 overflow-y-auto hide-scrollbar">
        {renderView()}
      </div>

      {/* Login Options Bottom Sheet - Global */}
      {showLoginSheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setShowLoginSheet(false)}
          ></div>

          <div className="bg-white w-full max-w-md rounded-t-3xl p-6 relative z-10 animate-in slide-in-from-bottom duration-300">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">
                选择登录方式
              </h3>
              <button onClick={() => setShowLoginSheet(false)}>
                <X size={20} className="text-gray-400" />
              </button>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setShowLoginSheet(false);
                  // 模拟登录成功，设置用户名但保持 GUEST 角色
                  setUser({
                    ...user,
                    name: "微信用户",
                    avatar:
                      "https://api.dicebear.com/7.x/avataaars/svg?seed=Wechat",
                  });
                  setTimeout(() => {
                    setSuccessModal({
                      isOpen: true,
                      title: "欢迎 微信用户",
                      message:
                        "完成课程/校园学生认证，即可享受专属权益！",
                      icon: "👋",
                    });
                  }, 300);
                }}
                className="w-full py-4 bg-green-500 text-white rounded-xl font-bold flex items-center justify-center gap-3 shadow-lg active:scale-95 transition-transform"
              >
                <MessageSquare size={20} />
                微信授权登录
              </button>

              <button
                onClick={() => {
                  setShowLoginSheet(false);
                  // 模拟登录成功，设置用户名但保持 GUEST 角色
                  setUser({
                    ...user,
                    name: "手机用户",
                    avatar:
                      "https://api.dicebear.com/7.x/avataaars/svg?seed=Phone",
                  });
                  setTimeout(() => {
                    setSuccessModal({
                      isOpen: true,
                      title: "欢迎 手机用户",
                      message:
                        "完成课程/校园学生认证，即可享受专属权益！",
                      icon: "👋",
                    });
                  }, 300);
                }}
                className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold flex items-center justify-center gap-3 shadow-lg active:scale-95 transition-transform"
              >
                <Phone size={20} />
                手机号码登录
              </button>
            </div>

            <p className="text-xs text-center text-gray-400 mt-6">
              登录即表示同意《用户协议》和《隐私政策》
            </p>
          </div>
        </div>
      )}

      <AuthModal
        isOpen={showGlobalAuth}
        onClose={() => setShowGlobalAuth(false)}
        onAuth={(role, name) => {
          setUser({
            ...user,
            role,
            name,
            quota: role === "COURSE" ? 3 : 0,
          });
          setSuccessModal({
            isOpen: true,
            title:
              role === "COURSE"
                ? "课程学生认证成功"
                : "校园学生认证成功",
            message:
              role === "COURSE"
                ? "欢迎您！3次免费打印权益已到账，快去体验吧！"
                : "欢迎您！现在可以享受校园学生专属折扣了！",
            icon: "🎓",
          });
        }}
      />

      <SuccessModal
        isOpen={successModal.isOpen}
        onClose={() =>
          setSuccessModal({ ...successModal, isOpen: false })
        }
        title={successModal.title}
        message={successModal.message}
        icon={successModal.icon}
      />

      <DeleteConfirmModal
        isOpen={deleteModal.isOpen}
        onClose={() =>
          setDeleteModal({ isOpen: false, taskId: null })
        }
        onConfirm={confirmDeleteTask}
        title="确认删除任务"
        message="删除后将无法恢复，确定要删除这个打印任务吗？"
      />

      {["TAB_PRINT", "TAB_TASK", "TAB_SHOP", "TAB_ME"].includes(
        currentView,
      ) && (
        <div className="bg-white border-t border-gray-200 pb-safe px-6 py-2 flex justify-between items-center text-[10px] font-medium text-gray-400">
          {[
            { id: "TAB_PRINT", label: "打印", icon: Printer },
            { id: "TAB_TASK", label: "任务", icon: FileText },
            {
              id: "TAB_SHOP",
              label: "商城",
              icon: ShoppingCart,
            },
            { id: "TAB_ME", label: "我的", icon: User },
          ].map((tab) => (
            <div
              key={tab.id}
              onClick={() => switchTab(tab.id)}
              className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${currentView === tab.id ? "text-blue-600" : "hover:text-gray-600"}`}
            >
              <tab.icon
                size={24}
                strokeWidth={currentView === tab.id ? 2.5 : 2}
              />
              <span>{tab.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}